// Lab 07 - Models | Kim Việt Quang - 2410900062 - K24CNT1
namespace lab07.Models.DataModels
{
    public class TvcMember
    {
        public string TvcMemberId { get; set; } = string.Empty;
        public string TvcUserName { get; set; } = string.Empty;
        public string TvcPassword { get; set; } = string.Empty;
        public string TvcFullName { get; set; } = string.Empty;
        public string TvcEmail { get; set; } = string.Empty;
    }
}
