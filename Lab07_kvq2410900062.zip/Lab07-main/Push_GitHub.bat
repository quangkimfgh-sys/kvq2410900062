@echo off
chcp 65001 >nul
title Push Lab07 - Kim Viet Quang 2410900062
cd /d "%~dp0"
where git >nul 2>&1 || (echo Chua cai Git & pause & exit /b 1)
if exist .git rmdir /s /q .git
git init
git add .
git commit -m "Lab 07 - Models - Kim Viet Quang 2410900062"
git branch -M main
git remote add origin https://github.com/VanHiepdangiu/Lab07.git
git push -u origin main
pause
