# Lab 07 - Models trong ASP.NET Core MVC

**Sinh viên:** Kim Việt Quang — **MSSV:** 2410900062 — **Lớp:** K24CNT1  
**Học phần:** Phát triển ứng dụng với công nghệ .NET

Bài làm theo project `TvcLesson07Models` trong source của thầy: https://github.com/tvchung/k24cnt1_netcore

## Nội dung
- Model `TvcMember` gồm MemberId, UserName, Password, FullName, Email.
- Danh sách 5 thành viên bằng Strongly Typed Model.
- Hiển thị một thành viên.
- Truyền danh sách bằng ViewBag.
- Form thêm thành viên với GET/POST và Anti-forgery token.

## URL
- `/TvcMember`
- `/TvcMember/GetMember`
- `/TvcMember/GetMembers`
- `/TvcMember/Create`

Mở `lab07.sln`, Build Solution và bấm F5.
