using Microsoft.AspNetCore.Mvc;
namespace lab13.Areas.Customer.Controllers;
[Area("Customer")]
public class HomeController : Controller { public IActionResult Index()=>View(); }
