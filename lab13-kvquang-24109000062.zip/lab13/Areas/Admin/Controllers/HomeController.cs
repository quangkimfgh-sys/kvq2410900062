using Microsoft.AspNetCore.Mvc;
namespace lab13.Areas.Admin.Controllers;
[Area("Admin")]
public class HomeController : Controller
{
    public IActionResult Index() => RedirectToAction("Index", "Dashboard", new { area = "Admin" });
}
