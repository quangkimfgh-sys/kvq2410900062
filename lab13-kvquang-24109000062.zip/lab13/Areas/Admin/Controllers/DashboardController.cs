using Microsoft.AspNetCore.Mvc;
namespace lab13.Areas.Admin.Controllers;
[Area("Admin")]
public class DashboardController : Controller { public IActionResult Index()=>View(); }
