using Microsoft.AspNetCore.Mvc;
namespace lab13.Controllers;
public class HomeController : Controller
{
    public IActionResult Index() => View();
    public IActionResult About() => View();
}
