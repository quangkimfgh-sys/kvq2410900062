using Microsoft.AspNetCore.Mvc;
using lab13.Models;
namespace lab13.Controllers;
public class ProductsController : Controller
{
    private static readonly List<KvqProduct> Products = new()
    {
        new(){Id=1,Name="iPhone 13 Pro",Price=13990000,Description="Điện thoại của Nguyễn Văn Hiệp",Active=true},
        new(){Id=2,Name="Samsung Galaxy S24",Price=16990000,Description="Màn hình AMOLED 120Hz",Active=true},
        new(){Id=3,Name="Xiaomi 14",Price=14990000,Description="Camera Leica",Active=false}
    };
    public IActionResult Index() => View(Products);
    public IActionResult Details(int id) => View(Products.FirstOrDefault(x=>x.Id==id) ?? Products[0]);
}
