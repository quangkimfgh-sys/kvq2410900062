using System.ComponentModel.DataAnnotations;
namespace lab13.Models;
public class KvqProduct
{
    public int Id { get; set; }
    [Display(Name="Tên sản phẩm")] public string Name { get; set; } = "";
    [Display(Name="Đơn giá")] public decimal Price { get; set; }
    [Display(Name="Mô tả")] public string Description { get; set; } = "";
    [Display(Name="Trạng thái")] public bool Active { get; set; }
}
