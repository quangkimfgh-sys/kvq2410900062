@echo off
chcp 65001 >nul
set /p REPO=Nhap URL GitHub repo: 
git init
git add .
git commit -m "Lab 13 - Nguyen Van Hiep 24109000062"
git branch -M main
git remote remove origin 2>nul
git remote add origin %REPO%
git push -u origin main
pause
