# LAB 13 – LAYOUT, CSS, JAVASCRIPT VÀ AREA

**Sinh viên:** Nguyễn Văn Hiệp – **MSSV:** 24109000062 – **Lớp:** K24CNT1

## Nội dung
- Custom Layout `_LayoutHome.cshtml` và `_ViewStart.cshtml`.
- CSS riêng, responsive trên điện thoại.
- JavaScript tự đánh dấu menu đang chọn.
- `ProductsController`, danh sách và chi tiết sản phẩm.
- MVC Area riêng cho `Admin` và `Customer`, mỗi Area có Layout riêng.

## Chạy bài
1. Mở `lab13.sln` bằng Visual Studio 2022.
2. Build Solution, sau đó nhấn `F5`.
3. Kiểm tra: `/`, `/Products`, `/Admin`, `/Customer`.

Bài làm dựa theo slide **Session 07 – Tìm hiểu về Layout**.
